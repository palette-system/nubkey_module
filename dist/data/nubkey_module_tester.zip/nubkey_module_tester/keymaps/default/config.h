// Copyright 2022 takashicompany (@takashicompany)
// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once

// #define POINTING_DEVICE_ROTATION_270
#define DYNAMIC_KEYMAP_LAYER_COUNT 1
#define PIMORONI_TRACKBALL_SCALE 1
#define POINTING_DEVICE_TASK_THROTTLE_MS 5